make
./exe $1 $2 $3
